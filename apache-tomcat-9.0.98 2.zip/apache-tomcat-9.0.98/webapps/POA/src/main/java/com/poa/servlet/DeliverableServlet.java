package com.poa.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.poa.Database.DbConnection;

public class DeliverableServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeliverableServlet() {
        super();
        
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String currentDate = request.getParameter("currentDate");
        
        if (currentDate == null || currentDate.isEmpty()) {
            currentDate = (String) session.getAttribute("currentDate");
            if (currentDate == null) {
                currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                session.setAttribute("currentDate", currentDate);
            }
        }

        String action = request.getParameter("action"); 

        try {
            DbConnection dbConnection = new DbConnection();
            int rowCount = Integer.parseInt(request.getParameter("rowCount"));
            for (int i = 1; i <= rowCount; i++) {
                String redmineNumber = request.getParameter("table" + i + "_redmine");
                String description = request.getParameter("table" + i + "_description");
                BigDecimal estTime = new BigDecimal(request.getParameter("table" + i + "_est_time"));

                if ("Update".equals(action)) {
                    
                	dbConnection.updateDeliverable(username, redmineNumber, description, estTime, currentDate);
                } else {
                   
                	dbConnection.Deliverables(username, redmineNumber, description, estTime, currentDate, "pending");
                }
            }

            response.sendRedirect("plan.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

}
