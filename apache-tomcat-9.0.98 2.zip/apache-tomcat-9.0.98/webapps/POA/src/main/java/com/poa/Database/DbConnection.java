package com.poa.Database;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.poa.view.Deliverable;
import com.poa.view.User;

public class DbConnection {
	private Connection con = null;
	private String dbName = "netweb_db";
	private String userName = "root";
	private String password = "netweb12";
	private String host = "localhost";
	private String url = "jdbc:mysql://" + host + "/" + dbName;

	public DbConnection() throws SQLException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, userName, password);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public Connection getCon() {
		return con;
	}

	public void close() throws SQLException {
		if (con != null) {
			con.close();
		}
	}

	public Integer validateLoginAndGetAuthorityId(String username, String password) throws SQLException {
        String query = "SELECT authority_id FROM emplyoee_personal_info WHERE Emp_id = ? AND Password = ?";
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            statement = this.con.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);
            resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("authority_id");
            } else {
                return null;
            }
        } finally {
            if (resultSet != null) resultSet.close();
            if (statement != null) statement.close();
        }
    }

	public void insertUnplannedWork(String empIdFk, String description, BigDecimal actualTime, String rework,
			String currentDate) throws SQLException {
		String query = "INSERT INTO UnplannedWork (Emp_id_fk, Description, ActualTime, ReWork,date) VALUES (?, ?, ?, ?,?)";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, empIdFk);
			pstmt.setString(2, description);
			pstmt.setBigDecimal(3, actualTime);
			pstmt.setString(4, rework);
			pstmt.setString(5, currentDate);
			pstmt.executeUpdate();
		}
	}

	public List<User> getRegisteredUsers(String userPk) {
		List<User> userList = new ArrayList<>();
		String query = "SELECT * FROM emplyoee_personal_info WHERE Emp_id=?";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, userPk);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setFirstName(rs.getString("firstName"));
				user.setLastName(rs.getString("lastName"));
				user.setEmployeeId(rs.getString("emp_id"));
				user.setDesignation(rs.getString("designation"));
				user.setContact(rs.getString("contact"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setProjectName(rs.getString("Project_name"));
				user.setGender(rs.getString("gender"));
				user.setJoiningDate(rs.getString("joiningDate"));
				user.setDateOfBirth(rs.getString("dateOfBirth"));
				userList.add(user);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return userList;
	}

	public List<User> getUsers() {
		List<User> userList = new ArrayList<>();
		String query = "SELECT *FROM emplyoee_personal_info";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setFirstName(rs.getString("firstName"));
				user.setLastName(rs.getString("lastName"));
				user.setEmployeeId(rs.getString("emp_id"));
				user.setDesignation(rs.getString("designation"));
				user.setContact(rs.getString("contact"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setProjectName(rs.getString("Project_name"));
				user.setGender(rs.getString("gender"));
				user.setJoiningDate(rs.getString("joiningDate"));
				user.setDateOfBirth(rs.getString("dateOfBirth"));
				userList.add(user);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return userList;
	}

	public void updateUser(String firstName, String lastName, String employeeId, String designation, String email,
			String contact, String password, String projectName, String gender, String joiningDate, String dateOfBirth)
			throws SQLException {
		String query = "UPDATE emplyoee_personal_info SET FirstName=?, LastName=?, Designation=?, Contact=?, Email=?, Password=?, Project_name=?, Gender=?, JoiningDate=?, DateOfBirth=? WHERE Emp_id=?";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {

			pstmt.setString(1, firstName);
			pstmt.setString(2, lastName);
			pstmt.setString(3, designation);
			pstmt.setString(4, contact);
			pstmt.setString(5, email);
			pstmt.setString(6, password);
			pstmt.setString(7, projectName);
			pstmt.setString(8, gender);
			pstmt.setString(9, joiningDate);
			pstmt.setString(10, dateOfBirth);
			pstmt.setString(11, employeeId);
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public void insertUserData(String firstName, String lastName, String employeeId, String designation, String email,
			String contact, String password, String projectName, String gender, String joiningDate, String dateOfBirth,
			String authorityId) throws SQLException {
		String query = "INSERT INTO emplyoee_personal_info (Emp_id, FirstName, LastName, Designation, Contact, Email, Password, Project_name, Gender, JoiningDate, DateOfBirth, authority_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, employeeId);
			pstmt.setString(2, firstName);
			pstmt.setString(3, lastName);
			pstmt.setString(4, designation);
			pstmt.setString(5, contact);
			pstmt.setString(6, email);
			pstmt.setString(7, password);
			pstmt.setString(8, projectName);
			pstmt.setString(9, gender);
			pstmt.setString(10, joiningDate);
			pstmt.setString(11, dateOfBirth);
			pstmt.setString(12, authorityId);
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

	public void insertDeliverables(String empIdFk, String redmineNumber, String description, BigDecimal estimatedTime,
			BigDecimal actualTime, BigDecimal overflow, String estVsAct, String rework, String status,
			String currentDate, String plan_status) throws SQLException {
		String query = "INSERT INTO Deliverables (Emp_id_fk, RedmineNumber, Description, EstimatedTime, ActualTime, Overflow, EstVsAct, ReWork, Status, DateCreated,plan_status) VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, empIdFk);
			pstmt.setString(2, redmineNumber);
			pstmt.setString(3, description);
			pstmt.setBigDecimal(4, estimatedTime);
			pstmt.setBigDecimal(5, actualTime);
			pstmt.setBigDecimal(6, overflow);
			pstmt.setString(7, estVsAct);
			pstmt.setString(8, rework);
			pstmt.setString(9, status);
			pstmt.setString(10, currentDate);
			pstmt.setString(11, plan_status);
			pstmt.executeUpdate();
		}
	}

	public void Deliverables(String empIdFk, String redmineNumber, String description, BigDecimal estimatedTime,
			String currentDate, String plan_status) throws SQLException {
		String query = "INSERT INTO Deliverables (Emp_id_fk, RedmineNumber, Description, EstimatedTime,DateCreated,plan_status) "
				+ "VALUES (?,?,?,?,?,?)";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, empIdFk);
			pstmt.setString(2, redmineNumber);
			pstmt.setString(3, description);
			pstmt.setBigDecimal(4, estimatedTime);
			pstmt.setString(5, currentDate);
			pstmt.setString(6, plan_status);
			pstmt.executeUpdate();
		}
	}
	public void updateDeliverable(String empIdFk, String redmineNumber, String description, BigDecimal estimatedTime, String currentDate) throws SQLException {
        String query = "UPDATE Deliverables SET Description = ?, EstimatedTime = ?, plan_status = 'pending' WHERE Emp_id_fk = ? AND RedmineNumber = ? AND DateCreated = ?";

        try (PreparedStatement pstmt = con.prepareStatement(query)) {
            pstmt.setString(1, description);
            pstmt.setBigDecimal(2, estimatedTime);
            pstmt.setString(3, empIdFk);
            pstmt.setString(4, redmineNumber);
            pstmt.setString(5, currentDate);
            pstmt.executeUpdate();
        }
    }
    


	public boolean checkPlanExists(String username, String date) {
	   
	    String query = "SELECT COUNT(*) FROM Deliverables WHERE Emp_id_fk = ? AND DateCreated = ?  AND plan_status = 'approved'";
	    try (
	         PreparedStatement pstmt = con.prepareStatement(query)) {
	        pstmt.setString(1, username);
	        pstmt.setString(2, date);

	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	           
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}


	public List<Deliverable> getDeliverables(String userpk, String startDate) {
		List<Deliverable> deliverables = new ArrayList<>();

		String query = "SELECT * FROM Deliverables WHERE Emp_id_fk = ? AND DateCreated = ? ";

		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, userpk);
			pstmt.setString(2, startDate);
			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					Deliverable deliverable = new Deliverable();
					deliverable.setEmpIdFk(rs.getString("Emp_id_fk"));
					deliverable.setRedmineNumber(rs.getString("RedmineNumber"));
					deliverable.setDescription(rs.getString("Description"));
					deliverable.setEstimatedTime(rs.getBigDecimal("EstimatedTime"));
					deliverable.setDateCreated(rs.getString("DateCreated"));
					deliverable.setPlanStatus(rs.getString("plan_status"));
					deliverable.setRemark(rs.getString("remarks"));
					deliverables.add(deliverable);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deliverables;
	}
	public List<Deliverable> getDeliverablesApproved(String userpk, String startDate) {
		List<Deliverable> deliverables = new ArrayList<>();

		String query = "SELECT * FROM Deliverables WHERE Emp_id_fk = ? AND DateCreated = ? AND plan_status = 'approved'";


		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, userpk);
			pstmt.setString(2, startDate);
			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					Deliverable deliverable = new Deliverable();
					deliverable.setEmpIdFk(rs.getString("Emp_id_fk"));
					deliverable.setRedmineNumber(rs.getString("RedmineNumber"));
					deliverable.setDescription(rs.getString("Description"));
					deliverable.setEstimatedTime(rs.getBigDecimal("EstimatedTime"));
					deliverable.setDateCreated(rs.getString("DateCreated"));
					deliverable.setPlanStatus(rs.getString("plan_status"));
					deliverable.setRemark(rs.getString("remarks"));
					deliverables.add(deliverable);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deliverables;
	}
	public List<Deliverable> getDeliverablesUser(String userpk, String startDate) {
		List<Deliverable> deliverables = new ArrayList<>();

		String query = "SELECT * FROM Deliverables WHERE Emp_id_fk = ? AND DateCreated = ? AND plan_status IN ('pending', 'Revised')";


		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, userpk);
			pstmt.setString(2, startDate);
			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					Deliverable deliverable = new Deliverable();
					deliverable.setEmpIdFk(rs.getString("Emp_id_fk"));
					deliverable.setRedmineNumber(rs.getString("RedmineNumber"));
					deliverable.setDescription(rs.getString("Description"));
					deliverable.setEstimatedTime(rs.getBigDecimal("EstimatedTime"));
					deliverable.setDateCreated(rs.getString("DateCreated"));
					deliverable.setPlanStatus(rs.getString("plan_status"));
					deliverable.setRemark(rs.getString("remarks"));
					deliverables.add(deliverable);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deliverables;
	}

	public List<Deliverable> getDeliverables(String userpk) {
		List<Deliverable> deliverables = new ArrayList<>();
		String query = "SELECT * FROM Deliverables WHERE Emp_id_fk=?";

		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, userpk);
			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					Deliverable deliverable = new Deliverable();
					deliverable.setEmpIdFk(rs.getString("Emp_id_fk"));
					deliverable.setRedmineNumber(rs.getString("RedmineNumber"));
					deliverable.setDescription(rs.getString("Description"));
					deliverable.setEstimatedTime(rs.getBigDecimal("EstimatedTime"));
					deliverable.setDateCreated(rs.getString("DateCreated"));
					deliverable.setPlanStatus(rs.getString("plan_status"));
					deliverables.add(deliverable);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return deliverables;
	}

	public void updateDeliverable(String redmineNumber, String remarks, String planStatus, String empId,
			String selectedDate) throws SQLException {
		String query = "UPDATE Deliverables SET Remarks = ?, plan_status = ? WHERE RedmineNumber = ? AND Emp_id_fk = ? AND DateCreated = ?";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, remarks);
			pstmt.setString(2, planStatus);
			pstmt.setString(3, redmineNumber);
			pstmt.setString(4, empId);
			pstmt.setString(5, selectedDate);
			pstmt.executeUpdate();
		}
	}

//	public List<User> getUsersWithPendingStatus() {
//	    List<User> userList = new ArrayList<>();
//	    Deliverable deliverable = new Deliverable();
//	    String query = "SELECT DISTINCT epi.firstName, epi.lastName, epi.emp_id, epi.designation, epi.email, d.Datecreated "
//	                 + "FROM employee_personal_info epi "
//	                 + "JOIN Deliverables d ON epi.Emp_id = d.Emp_id_fk "
//	                 + "WHERE d.plan_status = 'pending' "
//	                 + "ORDER BY d.Datecreated"; 
//
//	    try (PreparedStatement pstmt = con.prepareStatement(query);
//	         ResultSet rs = pstmt.executeQuery()) {
//	        while (rs.next()) {
//	            User user = new User();
//	            user.setFirstName(rs.getString("firstName"));
//	            user.setLastName(rs.getString("lastName"));
//	            user.setEmployeeId(rs.getString("emp_id"));
//	            user.setDesignation(rs.getString("designation"));
//	            user.setEmail(rs.getString("email"));
//	            deliverable.setDateCreated(rs.getString("DateCreated"));
//
//	            userList.add(user);
//	        }
//	    } catch (SQLException ex) {
//	        ex.printStackTrace();
//	    }
//	    return userList;
//	}

	public List<User> getUsersWithPendingStatusByDate(Date date) {
		List<User> userList = new ArrayList<>();
		String query = "SELECT DISTINCT epi.firstName, epi.lastName, epi.emp_id, epi.designation, epi.email "
				+ "FROM `emplyoee_personal_info` epi " + "JOIN Deliverables d ON epi.Emp_id = d.Emp_id_fk "
				+ "WHERE d.plan_status = 'pending' AND DATE(d.Datecreated) = ? " + "ORDER BY d.Datecreated";

		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setDate(1, date);
			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					User user = new User();
					user.setFirstName(rs.getString("firstName"));
					user.setLastName(rs.getString("lastName"));
					user.setEmployeeId(rs.getString("emp_id"));
					user.setDesignation(rs.getString("designation"));
					user.setEmail(rs.getString("email"));
					userList.add(user);
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return userList;
	}

	public List<User> getUsersWithPendingStatus() {
		List<User> userList = new ArrayList<>();
		String query = "SELECT DISTINCT epi.firstName, epi.lastName, epi.emp_id, epi.designation, epi.email "
				+ "FROM `emplyoee_personal_info` epi " + "JOIN Deliverables d ON epi.Emp_id = d.Emp_id_fk "
				+ "WHERE d.plan_status = 'pending' " + "ORDER BY d.Datecreated";

		try (PreparedStatement pstmt = con.prepareStatement(query); ResultSet rs = pstmt.executeQuery()) {
			while (rs.next()) {
				User user = new User();
				user.setFirstName(rs.getString("firstName"));
				user.setLastName(rs.getString("lastName"));
				user.setEmployeeId(rs.getString("emp_id"));
				user.setDesignation(rs.getString("designation"));
				user.setEmail(rs.getString("email"));
				userList.add(user);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return userList;
	}

	public void deleteUser(String employeeId) throws SQLException {
		String query = "DELETE FROM users WHERE employee_id=?";
		try (PreparedStatement pstmt = con.prepareStatement(query)) {
			pstmt.setString(1, employeeId);
			pstmt.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
	}

}
