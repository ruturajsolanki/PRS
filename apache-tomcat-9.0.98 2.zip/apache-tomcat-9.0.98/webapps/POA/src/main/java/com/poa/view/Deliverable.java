package com.poa.view;

import java.math.BigDecimal;

public class Deliverable {
    private String empIdFk;
    private String redmineNumber;
    private String description;
    private BigDecimal estimatedTime;
    private BigDecimal actualTime; 
    private BigDecimal estVsAct;   
    private String dateCreated;
    private String planStatus;
    private String remark;
    private String rework;   
    private String status;    

    public Deliverable(String empIdFk, String redmineNumber, String description, BigDecimal estimatedTime,
                       BigDecimal actualTime, String dateCreated, String planStatus, String remark,
                       String rework, String status) { 
        this.empIdFk = empIdFk;
        this.redmineNumber = redmineNumber;
        this.description = description;
        this.estimatedTime = estimatedTime;
        this.actualTime = actualTime;  
        this.dateCreated = dateCreated;
        this.planStatus = planStatus;
        this.remark = remark;
        this.rework = rework;     
        this.status = status;  
        this.updateEstVsAct();       
    }

    public Deliverable() {
        super();
    }

   
   

    public void setRework(String rework) {
        this.rework = rework;
    }
    public String getRework() {
        return rework;
    }
  
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Existing getters and setters below...

    public String getEmpIdFk() {
        return empIdFk;
    }

    public void setEmpIdFk(String empIdFk) {
        this.empIdFk = empIdFk;
    }

    public String getRedmineNumber() {
        return redmineNumber;
    }

    public void setRedmineNumber(String redmineNumber) {
        this.redmineNumber = redmineNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getEstimatedTime() {
        return estimatedTime;
    }

    public void setEstimatedTime(BigDecimal estimatedTime) {
        this.estimatedTime = estimatedTime;
        this.updateEstVsAct(); 
    }

    public BigDecimal getActualTime() {
        return actualTime;
    }

    public void setActualTime(BigDecimal actualTime) {
        this.actualTime = actualTime;
        this.updateEstVsAct(); 
    }

    public BigDecimal getEstVsAct() {
        return estVsAct;
    }

    private void updateEstVsAct() {
        if (this.estimatedTime != null && this.actualTime != null) {
            this.estVsAct = this.actualTime.subtract(this.estimatedTime);
        }
    }

    public String getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(String dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getPlanStatus() {
        return planStatus;
    }

    public void setPlanStatus(String planStatus) {
        this.planStatus = planStatus;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
