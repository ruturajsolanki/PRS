package com.poa.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.poa.Database.DbConnection;

@WebServlet(name = "LoginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DbConnection dbConnection;

    public void init() throws ServletException {
        try {
            dbConnection = new DbConnection();
        } catch (SQLException e) {
            throw new ServletException("Initialization failed, unable to obtain DB connection", e);
        }
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String currentDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        try {
            Integer authorityId = dbConnection.validateLoginAndGetAuthorityId(username, password);
            if (authorityId != null) {
                HttpSession session = request.getSession();
                session.setAttribute("username", username);

                boolean planExists = dbConnection.checkPlanExists(username, currentDate);

                switch (authorityId) {
                    case 1:
                        response.sendRedirect(planExists ? "planAllocation.jsp" : "plan.jsp");
                        break;
                    case 2:
                        response.sendRedirect("UserList.jsp");
                        break;
                    case 3:
                        response.sendRedirect("pendingStatus");
                        break;
                    default:
                        response.sendRedirect("index.jsp?error=invalid");
                        break;
                }
            } else {
                response.sendRedirect("index.jsp?error=invalid");
            }
        } catch (SQLException ex) {
            throw new ServletException("Error during login validation", ex);
        }
    }

}
