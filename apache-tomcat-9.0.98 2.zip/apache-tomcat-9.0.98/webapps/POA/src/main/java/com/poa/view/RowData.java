package com.poa.view;

public class RowData {
    private String redmineNumber;
    private String description;
    private String estTime;
    private String actualTime;
    private String overflow;
    private String estVsAct;
    private String rework;

    // Constructors, getters, and setters
    // Note: You can generate these using your IDE or write them manually

    public RowData(String redmineNumber, String description, String estTime, String actualTime, String overflow, String estVsAct, String rework) {
        this.redmineNumber = redmineNumber;
        this.description = description;
        this.estTime = estTime;
        this.actualTime = actualTime;
        this.overflow = overflow;
        this.estVsAct = estVsAct;
        this.rework = rework;
    }

    public String getRedmineNumber() {
        return redmineNumber;
    }

    public void setRedmineNumber(String redmineNumber) {
        this.redmineNumber = redmineNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEstTime() {
        return estTime;
    }

    public void setEstTime(String estTime) {
        this.estTime = estTime;
    }

    public String getActualTime() {
        return actualTime;
    }

    public void setActualTime(String actualTime) {
        this.actualTime = actualTime;
    }

    public String getOverflow() {
        return overflow;
    }

    public void setOverflow(String overflow) {
        this.overflow = overflow;
    }

    public String getEstVsAct() {
        return estVsAct;
    }

    public void setEstVsAct(String estVsAct) {
        this.estVsAct = estVsAct;
    }

    public String getRework() {
        return rework;
    }

    public void setRework(String rework) {
        this.rework = rework;
    }
}
