package com.poa.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poa.Database.DbConnection;

@WebServlet(urlPatterns = "/updateprofile")
public class UpdateProfile extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public UpdateProfile() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        response.getWriter().append("Method not allowed");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String employeeId = request.getParameter("employeeId");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String designation = request.getParameter("designation");
        String email = request.getParameter("email");
        String contact = request.getParameter("contact"); 
        String password = request.getParameter("password");
        String projectName = request.getParameter("projectName");
        String gender = request.getParameter("gender");
        String joiningDate = request.getParameter("joiningDate");
        String dateOfBirth = request.getParameter("dateOfBirth");
        
        
        try {
            DbConnection dbConnection = new DbConnection();
            dbConnection.updateUser(firstName, lastName, employeeId, designation, email, contact, password, projectName,
                    gender, joiningDate, dateOfBirth);
            dbConnection.close();

            response.sendRedirect("user.jsp");
        } catch (Exception e) {
            e.printStackTrace();

            response.sendRedirect("error.jsp");
        }
    }
}
