package com.poa.servlet;

import com.poa.Database.DbConnection;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteUser")
public class DeleteUserServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String employeeId = request.getParameter("employeeId");

        
        DbConnection dbConnection = null;
        try {
            dbConnection = new DbConnection();
            dbConnection.deleteUser(employeeId);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (dbConnection != null) {
                try {
                    dbConnection.close();	
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        
        response.sendRedirect(request.getContextPath() + "/UserList.jsp");
    }
}
