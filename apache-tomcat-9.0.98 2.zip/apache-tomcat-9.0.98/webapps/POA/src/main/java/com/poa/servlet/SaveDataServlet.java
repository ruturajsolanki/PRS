package com.poa.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.poa.Database.DbConnection;

public class SaveDataServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");
        String currentDate = request.getParameter("currentDate");

        try {
            DbConnection dbConnection = new DbConnection();

            // Handling planned deliverables
            int rowCount = Integer.parseInt(request.getParameter("rowCount"));
            for (int i = 1; i <= rowCount; i++) {
                String redmineNumber = request.getParameter("table" + i + "_redmine");
                String description = request.getParameter("table" + i + "_description");
                BigDecimal estTime = new BigDecimal(request.getParameter("table" + i + "_est_time"));
                BigDecimal actualTime = new BigDecimal(request.getParameter("table" + i + "_actual_time"));
                BigDecimal overflow = new BigDecimal(request.getParameter("table" + i + "_overflow"));
                String estVsAct = request.getParameter("table" + i + "_est_vs_act");
                String rework = request.getParameter("table" + i + "_rework");
                String status = request.getParameter("table" + i + "_status");
                String plan_status="pending";

                dbConnection.insertDeliverables(username, redmineNumber, description, estTime, actualTime, overflow, estVsAct, rework, 
                		status, currentDate,plan_status);

            }
            
//         // Handling Unplanned deliverables
//            int unplannedRowCount = Integer.parseInt(request.getParameter("unplannedWorkRowCount"));
//            for (int i = 1; i <= unplannedRowCount; i++) {
//                String description = request.getParameter("unplannedWorkTable" + i + "_description");
//                BigDecimal actualTime = new BigDecimal(request.getParameter("unplannedWorkTable" + i + "_actual_time"));
//                String rework = request.getParameter("unplannedWorkTable" + i + "_rework");
//
//                
//                dbConnection.insertUnplannedWork(username, description, actualTime, rework, currentDate);
//            }

            response.sendRedirect("planAllocation.jsp");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
