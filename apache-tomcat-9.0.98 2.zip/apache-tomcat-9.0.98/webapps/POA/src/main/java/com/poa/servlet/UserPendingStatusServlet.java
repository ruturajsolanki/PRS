package com.poa.servlet;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.poa.Database.DbConnection;
import com.poa.view.User;

@WebServlet(name = "UserPendingStatusServlet", urlPatterns = "/pendingStatus")
public class UserPendingStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public UserPendingStatusServlet() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String date = request.getParameter("selectedDate");
        if (date == null || date.isEmpty()) {
            date = LocalDate.now().toString(); 
        }

        DbConnection dbConnection = null;
        try {
            dbConnection = new DbConnection();
            List<User> usersWithPending;
            usersWithPending = dbConnection.getUsersWithPendingStatusByDate(Date.valueOf(date));
            request.setAttribute("usersWithPending", usersWithPending);
            request.setAttribute("selectedDate", date);  // Set the selected date attribute for use in the JSP

            RequestDispatcher dispatcher = request.getRequestDispatcher("/approver.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error occurred");
        } finally {
            if (dbConnection != null) {
                try {
                    dbConnection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}
