package com.poa.servlet;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.poa.Database.DbConnection;
import com.poa.view.User;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            DbConnection dbConnection = new DbConnection();
            List<User> userList = dbConnection.getUsers();
            request.setAttribute("users", userList);
            dbConnection.close();
            request.getRequestDispatcher("UserList.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
          
        }
    }
}
