package com.poa.servlet;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.poa.Database.DbConnection;

@WebServlet("/registration")
public class Registration extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstName = request.getParameter("firstName");
        String employeeId = request.getParameter("emp_id");
        String lastName = request.getParameter("lastName");
        String designation = request.getParameter("designation");
        String contact = request.getParameter("contact");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String projectName = request.getParameter("projectName");
        String gender = request.getParameter("gender");
        String joiningDate = request.getParameter("joiningDate");
        String dateOfBirth = request.getParameter("dateOfBirth");
        String authorityId = request.getParameter("authority_id"); 
        
        try {
            DbConnection dbConnection = new DbConnection();
            
            dbConnection.insertUserData(firstName, lastName, employeeId, designation, email, contact, password, projectName, gender, joiningDate, dateOfBirth, authorityId); // Pass authorityId
            
            dbConnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("registration.jsp?error=An error occurred during registration");
            return;
        }
        
        response.sendRedirect("index.jsp");
    }
}
