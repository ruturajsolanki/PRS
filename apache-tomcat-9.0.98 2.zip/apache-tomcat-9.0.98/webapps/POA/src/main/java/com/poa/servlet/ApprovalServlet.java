package com.poa.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.poa.Database.DbConnection;

public class ApprovalServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public ApprovalServlet() {
        super();
       
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        try  {
        	DbConnection dbConnection = new DbConnection();
            if ("Revise".equals(action)) {
                reviseDeliverables(request, dbConnection);
            } else if ("Approval".equals(action)) {
                approveDeliverables(request, dbConnection);
            }
            response.sendRedirect("approver.jsp"); 
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }

    private void reviseDeliverables(HttpServletRequest request, DbConnection dbConnection) throws SQLException {
        String empId = request.getParameter("empId");
        String selectedDate = request.getParameter("currentDate");
        int rowCount = Integer.parseInt(request.getParameter("rowCount"));
        for (int i = 1; i <= rowCount; i++) {
            String redmine = request.getParameter("redmine" + i);
            String remarks = request.getParameter("remark" + i);
            dbConnection.updateDeliverable(redmine, remarks, "Revised", empId, selectedDate);
        }
    }


    private void approveDeliverables(HttpServletRequest request, DbConnection dbConnection) throws SQLException {
        String empId = request.getParameter("empId");
        String selectedDate = request.getParameter("currentDate");
        int rowCount = Integer.parseInt(request.getParameter("rowCount"));
        for (int i = 1; i <= rowCount; i++) {
            String redmine = request.getParameter("redmine" + i);
            String remarks = request.getParameter("remark" + i);
            dbConnection.updateDeliverable(redmine, remarks, "Approved", empId, selectedDate);
        }
    }


}
